# Tendrr Analytics plugin for Craft CMS 3.x

Custom analytics charting for Tendrr

![Screenshot](resources/img/plugin-logo.png)

## Requirements

This plugin requires Craft CMS 3.0.0-beta.23 or later.

## Installation

To install the plugin, follow these instructions.

1. Open your terminal and go to your Craft project:

        cd /path/to/project

2. Then tell Composer to load the plugin:

        composer require jedgueruela/tendrr-analytics

3. In the Control Panel, go to Settings → Plugins and click the “Install” button for Tendrr Analytics.

## Tendrr Analytics Overview

-Insert text here-

## Configuring Tendrr Analytics

-Insert text here-

## Using Tendrr Analytics

-Insert text here-

## Tendrr Analytics Roadmap

Some things to do, and ideas for potential features:

* Release it

Brought to you by [Jed Gueruela](https://cell5.co.uk)
